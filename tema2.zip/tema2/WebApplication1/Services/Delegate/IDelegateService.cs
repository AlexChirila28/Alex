﻿namespace WebApplication1.Services.Delegate
{
    public interface IDelegateService
    {
        string Introduction(string value, Func<string, string, string> callback);

        string Hello(string firstname, string lastname);

        string ConditionalGreeting(string name, bool isWelcome);
        void ExecutePostOperations(string result, Action<string> finalCallback);
        string ProcessWithMultipleCallbacks(string input, params Func<string, string>[] processors);
    }
}
