﻿namespace WebApplication1.Services.Delegate
{
    public class DelegateService : IDelegateService
    {
        public string Introduction(string value, Func<string, string, string> callback)
        {
            var upperName = value.ToUpper();
            return callback(upperName, "Test");
        }

        public string Hello(string firstname, string lastname)
        {
            return $"Salut, {firstname} {lastname}";
        }

        public string Goodbye(string firstname, string lastname)
        {
            return $"La Revedere, {firstname} {lastname}";
        }

        public string ConditionalGreeting(string name, bool isWelcome)
        {
            Func<string, string, string> greetingDelegate = isWelcome ? Hello : Goodbye;
            return greetingDelegate(name, "Utilizator");
        }

        public void ExecutePostOperations(string result, Action<string> finalCallback)
        {
            Console.WriteLine($"Procesare inițială completă: {result}");
            finalCallback?.Invoke(result);
            Console.WriteLine("Toate operațiunile completate");
        }

        public string ProcessWithMultipleCallbacks(string input, params Func<string, string>[] processors)
        {
            string result = input;
            foreach (var processor in processors)
            {
                result = processor(result);
            }
            return result;
        }
    }
}
