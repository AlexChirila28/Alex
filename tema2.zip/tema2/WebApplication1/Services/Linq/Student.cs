﻿namespace WebApplication1.Services.Linq
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Department { get; set; }
        public double Grade { get; set; }

        public Student(int id, string name, int age, string department, double grade)
        {
            Id = id;
            Name = name;
            Age = age;
            Department = department;
            Grade = grade;
        }
    }
}
