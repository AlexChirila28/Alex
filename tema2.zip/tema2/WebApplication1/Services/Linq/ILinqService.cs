﻿namespace WebApplication1.Services.Linq
{
    public interface ILinqService
    {
        int CountStudentsOver(int value);

        IEnumerable<Student> GetStudentsInDepartment(string department);

        IEnumerable<string> GetStudentNames();

        int CountStudents();


        IEnumerable<string> GetDepartmentStudentsWithCode();
    }
}
