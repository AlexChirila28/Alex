﻿namespace WebApplication1.Services.Linq
{
    public static class StudentData
    {
        public static List<Student> Students = new List<Student>
        {
            new Student(1, "Andrei", 22, "Informatica", 3.5)
                 ,
            new Student(2, "Alexandru", 20, "Matematica", 3.8)
                ,
            new Student(3, "Vlad", 23, "Informatica", 3.9)
                ,
            new Student(4, "Sebastian", 22, "Fizica", 3.2)
               ,
            new Student(5, "Florin", 22, "Matematica", 3.3)
                 
        };
    }
}
