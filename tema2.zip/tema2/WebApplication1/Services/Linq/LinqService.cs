﻿namespace WebApplication1.Services.Linq
{
    

    public class LinqService : ILinqService
    {
        public class Department
        {
            public string FullName { get; }
            public string Code { get; }

            public Department(string fullName, string code)
            {
                FullName = fullName;
                Code = code;
            }
        }
        public int CountStudentsOver(int value)
        {
            //Expresie de interogare 
            //var query = from student in stUdents
            //            where student.Age >= value
            //                select student;

            //return query.Count();

            //Metoda de expresie 
            return StudentData.Students.Count(student => student.Age >= value);
        }

        public IEnumerable<Student> GetStudentsInDepartment(string department)
        {
            var methodExpr = StudentData.Students.Where(s => s.Department == department);

            return methodExpr;
        }

       
        public IEnumerable<string> GetStudentNames()
        {
            var queryExpr = from student in StudentData.Students
                            select student.Name;

            return queryExpr;
        }

        
        public int CountStudents()
        {
            
            var methodExpr = StudentData.Students.Count;

            return methodExpr;
        }



        public IEnumerable<string> GetDepartmentStudentsWithCode()
        {
            var departments = new List<Department>
            {
                new Department("Informatica", "CS"),
                new Department("Matematica", "MATH"),
                new Department("Fizica", "PHY")
            };

            
            var methodExpr = StudentData.Students
                .Where(s => s.Age > 20) 
                .Join(departments,
                    student => student.Department,
                    dept => dept.FullName,
                    (student, dept) => $"{student.Name} ({dept.Code}) - Nota: {student.Grade}");

            return methodExpr;
        }


    }

}

