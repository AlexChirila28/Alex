﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services.Lambda;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLambdaController : ControllerBase
    {
        private readonly ILambdaService _lambdaService;

        public TestLambdaController(ILambdaService lambdaService)
        {
            _lambdaService = lambdaService;
        }

        [HttpGet("split-number")]
        public string SplitNumber(int value)
        {
            var tupleValue = _lambdaService.SplitNumber(value);
            return $"{tupleValue.Item1} / {tupleValue.Item2} / {tupleValue.Item3}";
        }

        [HttpGet("try-parse-number")]
        public string TryParseNumber(string value)
        {
            return _lambdaService.TryParseNumber(value) ? "Number" : "Not number";
        }

        [HttpGet("lower-case-delayed")]
        public string ToLowerCaseDelayed(string value)
        {
            var result = _lambdaService.ToLowerCaseDelayed(value).Result;
            return result;
        }

        [HttpGet("no-param")]
        public string NoParam()
        {
            Func<string> nothing = () => "No parameter";
            return nothing();
        }

        [HttpGet("two-params")]
        public string TwoParams(int p1, int p2)
        {
            Func<int, int, int> myLambda = (a, b) => a + b;
            int result = myLambda(p1, p2);
            return result.ToString();
        }

        [HttpGet("unused")]
        public string UnusedParam(string p1, string p2, string p3)
        {
            Func<string, string, string, string> myLambda = (a, b, _) => string.Join("/", [a, b]);
            return myLambda(p1, p2, p3);
        }

        [HttpGet("default")]
        public int DefaultParam(int v, int incBy)
        {
            var myLambda = int (int value, int incrementBy = 1) =>
            {
                if (incrementBy % 2 == 1)
                {
                    return (value + incrementBy) * 5;
                }
                return value + incrementBy;
            };
            return myLambda(v, incBy);
        }

        [HttpGet("async-lambda")]
        public async Task<IActionResult> AsyncLambda(int delayMs = 1000)
        {
            Func<int, Task<string>> delayExpr = async ms =>
                await Task.Delay(ms).ContinueWith(_ => $"Waited {ms}ms");

            

            var resultExpr = await delayExpr(delayMs);
            

            return Ok(new
            {
                ExpressionResult = resultExpr
            });
        }
    }
}
