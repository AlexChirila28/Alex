﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services.Linq;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLinqController : ControllerBase
    {
        private readonly ILinqService _linqService;

        public TestLinqController(ILinqService linqService)
        {
            _linqService = linqService;
        }

        [HttpGet("count-students-over")]
        public int CountStudentsOver(int age)
        {
            return _linqService.CountStudentsOver(age);
        }

        [HttpGet("department-students")]
        public IEnumerable<Student> GetDepartmentStudents(string department) =>
           _linqService.GetStudentsInDepartment(department);

        [HttpGet("student-names")]
        public IEnumerable<string> GetStudentNames() => _linqService.GetStudentNames();

        [HttpGet("total-students")]
        public int GetTotalStudents() => _linqService.CountStudents();
        [HttpGet("department-students-with-code")]
        public IEnumerable<string> GetDepartmentStudentsWithCode()
        {
            return _linqService.GetDepartmentStudentsWithCode();
        }
    }
}
