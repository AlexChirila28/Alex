﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services.Delegate;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestDelegateController : ControllerBase
    {
        private readonly IDelegateService _delegateService;
        delegate string MyDelegate(string value);

        public TestDelegateController(IDelegateService delegateService)
        {
            _delegateService = delegateService;
        }

        [HttpGet("intro")]
        public string Introduction(string name)
        {
            var callback = _delegateService.Hello;

            return _delegateService.Introduction(name, callback);
        }

        [HttpGet("intro-condition")]
        public string IntroductionCondition(string name, bool welcome)
        {
            var callback1 = _delegateService.Hello;
            var callback2 = (string firstname, string lastname) => $"Bye, {firstname} {lastname}";

            var callback = welcome ? callback1 : callback2;

            return _delegateService.Introduction(name, callback);
        }

        [HttpGet("conditional-greeting")]
        public string ConditionalGreeting(string name, bool isWelcome)
        {
            return _delegateService.ConditionalGreeting(name, isWelcome);
        }
       

        
        [HttpGet("full-example")]
        public string FullExample(string name, bool isWelcome)
        {           
            var intro = _delegateService.Introduction(name, (f, l) =>
                isWelcome ? $"Welcome {f} {l}" : $"See you later {f} {l}");
            
            var greeting = _delegateService.ConditionalGreeting(name, isWelcome);

            var processed = _delegateService.ProcessWithMultipleCallbacks(
                greeting,
                s => s.ToUpper(),
                s => $"{s}!!!",
                s => $"RESULT: {s}");

            return processed;
        }
    }
}
