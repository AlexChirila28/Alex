
using WebApplication1.Services.Delegate;
using WebApplication1.Services.Lambda;
using WebApplication1.Services.Linq;

namespace WebApplication1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            //Adauga servicii �n container

            builder.Services.AddControllers();
            //Afla mai multe despre configurarea Swagger/OpenAPI la https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddScoped<IDelegateService, DelegateService>();
            builder.Services.AddScoped<ILambdaService, LambdaService>();
            builder.Services.AddScoped<ILinqService, LinqService>();

            var app = builder.Build();

            //Configureaza pipeline-ul de cereri HTTP
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
