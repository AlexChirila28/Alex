﻿namespace ConsoleProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Initializare Client...");

            MemberSystem member = new MemberSystem();
            BookSystem book = new BookSystem();
            RegularMember member1 = new RegularMember("Jules V");
            HardcoverBook book1 = new HardcoverBook("Insula misterioasă", "Călătorie spre centrul Pământului");
            book.AddBook(book1);
            member.AddMember(member1);
            book.BorrowBook(member1, book1, member);
            book.ReturnBook(member1, book1);
            book.RemoveBook(book1);
            member.RemoveMember(member1);
        }
    }
}
