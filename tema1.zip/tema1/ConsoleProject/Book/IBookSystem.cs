﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public interface IBookSystem
    {
        void AddBook(IBook book);
        void RemoveBook(IBook book);

        void BorrowBook(IMember member, IBook book, MemberSystem members);
        void ReturnBook(IMember member, IBook book);
    }
}
