﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public interface IBook
    {
        string Title { get; set; }
        string Description();
    }
}
