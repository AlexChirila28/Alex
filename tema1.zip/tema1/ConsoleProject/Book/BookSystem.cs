﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public class BookSystem : IBookSystem
    {
        private List<IBook> books = new List<IBook>();
        public void AddBook(IBook book)
        {
            books.Add(book);
            Console.WriteLine("Carte adaugata : " + book.Title); //book added
        }

        public void RemoveBook(IBook book)
        {
            books.Remove(book);
            Console.WriteLine("Carte stearsa: " + book.Title); // book removed
        }

        public void BorrowBook(IMember member, IBook book, MemberSystem members)
        {
            if (books.Contains(book) && members.IsMemberExists(member))
            {
                books.Remove(book);
                Console.WriteLine($"{member.Name} imprumuta {book.Title}"); //borrowed
            }
            else
            {
                Console.WriteLine("Carte sau membru negasit.");
            }
        }

        public void ReturnBook(IMember member, IBook book)
        {
            books.Add(book);
            Console.WriteLine($"{member.Name} returneaza {book.Title}"); //returned
        }
    }   

}