﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public class HardcoverBook : IBook
    {   
        public string Title { get; set; }
        public string Author { get; set; }

        public HardcoverBook(string title, string author)
        {
            Title = title;
            Author = author;
        }
        public string Description()
        {
            return $"Title: {Title} by {Author}";
        }
    }

    public class EBook : IBook
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public EBook(string title, string author)
        {
            Title = title;
            Author = author;
        }
        public string Description()
        {
            return $"Title: {Title} by {Author}";
        }
    }
}
