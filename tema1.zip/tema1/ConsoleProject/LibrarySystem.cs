﻿namespace ConsoleProject
{
    //Această clasă încalcă Principiul Responsabilității Unice (SRP) prin gestionarea mai multor responsabilități.
    public class LibrarySystem : ILibrarySystem
    {
        private List<string> books = new List<string>();
        private List<string> members = new List<string>();

        // Această metodă încalcă Principiul Deschis/Închis (OCP) deoarece necesită modificări pentru a adăuga noi tipuri de cărți.
        public void AddBook(string book)
        {
            books.Add(book);
        }

        // Această metodă încalcă Principiul Substituției Liskov (LSP) deoarece presupune că toți membrii sunt de același tip.
        public void AddMember(string member)
        {
            members.Add(member);
        }

        // Această metodă încalcă Principiul Segregării Interfeței (ISP) prin forțarea clienților să implementeze metode de care nu au nevoie.
        public void BorrowBook(string member, string book)
        {
            if (books.Contains(book) && members.Contains(member))
            {
                books.Remove(book);
                Console.WriteLine($"{member} imprumutat {book}");
            }
            else
            {
                Console.WriteLine("Carte sau membru negasit.");
            }
        }

        // Această metodă încalcă Principiul Inversiunii Dependenței (DIP) prin dependența de clase concrete în loc de abstracții.
        public void ReturnBook(string member, string book)
        {
            books.Add(book);
            Console.WriteLine($"{member} returnat {book}");
        }
    }
}
