﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public class RegularMember : IMember
    {   
        public string Name { get; set; }
        public RegularMember(string name)
        {
            Name = name;
        }
        public string Description()
        {
            return $"Membru obisnuit: {Name}";
        }
    }

    public class PremiumMember : IMember
    {
        public string Name { get; set; }
        public string ExpirationDate { get; set; }
        public PremiumMember(string name, string expirationDate)
        {
            Name = name;
            ExpirationDate = expirationDate;
        }
        public string Description()
        {
            return $"Membru premium: {Name}";
        }
    }

}
