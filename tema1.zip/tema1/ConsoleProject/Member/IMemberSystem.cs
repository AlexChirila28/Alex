﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public interface IMemberSystem
    {
        void AddMember(IMember member);
        bool IsMemberExists(IMember member);

        void RemoveMember(IMember member);
    }
}
