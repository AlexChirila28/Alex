﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public interface IMember
    {   
        string Name { get; set; }
        string Description();
    }
}
