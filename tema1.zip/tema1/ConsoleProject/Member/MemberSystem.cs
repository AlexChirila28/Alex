﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject
{
    public class MemberSystem : IMemberSystem
    {
        public List<IMember> members = new List<IMember>();
        public void AddMember(IMember member)
        {   
            members.Add(member);
            Console.WriteLine("Membru adaugat: " + member.Name);
        }

        public bool IsMemberExists(IMember member)
        {
            return members.Contains(member);
        }

        public void RemoveMember(IMember member)
        {
            members.Remove(member);
            Console.WriteLine("Membru sters: " + member.Name);
        }
    }
}
