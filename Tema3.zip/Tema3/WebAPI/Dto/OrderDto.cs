﻿using DataAccessLayer.Models;

namespace WebAPI.Dto
{
    public class OrderDto
    {
        public string OrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public int CustomerId { get; set; }
    }
}
