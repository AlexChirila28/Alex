﻿namespace WebAPI.Dto
{
    public class PassportDto
    {
        public string PassportNumber { get; set; }
        public string Nationality { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int CustomerId { get; set; }
    }
}
