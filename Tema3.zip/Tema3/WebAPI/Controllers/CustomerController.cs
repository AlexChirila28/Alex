﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {

        private readonly IRepository<Customer> _customerRepository;


        public CustomerController(IRepository<Customer> customerRepository)
        {
            _customerRepository = customerRepository;
        }


        [HttpGet("get")]
        public IEnumerable<Customer> Get()
        {
            return _customerRepository.GetAll();
        }

        [HttpPost("add")]
        public ObjectResult Add(CustomerDto customerDto)
        {
            _customerRepository.Add(new Customer(customerDto.Name, customerDto.Email, customerDto.Password));
            _customerRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public ObjectResult Update(int id, CustomerDto CustomerDto)
        {
            throw new NotImplementedException();
        }



        [HttpPut("delete")]
        public ObjectResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
