﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PassportController : ControllerBase
    {

        private readonly IRepository<Passport> _passportRepository;


        public PassportController(IRepository<Passport> passportRepository)
        {
            _passportRepository = passportRepository;
        }


        [HttpGet("get")]
        public IEnumerable<Passport> Get()
        {
            return _passportRepository.GetAll();
        }

        [HttpPost("add")]
        public ObjectResult Add(PassportDto passportDto)
        {
            var passport = new Passport
            {
                PassportNumber = passportDto.PassportNumber,
                Nationality = passportDto.Nationality,
                ExpiryDate = passportDto.ExpiryDate,
                CustomerId = passportDto.CustomerId
            };
            _passportRepository.Add(passport);
            _passportRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public ObjectResult Update(int id, PassportDto passportDto)
        {
            throw new NotImplementedException();
        }



        [HttpPut("delete")]
        public ObjectResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
