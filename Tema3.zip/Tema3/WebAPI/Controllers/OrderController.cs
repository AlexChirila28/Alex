﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {

        private readonly IRepository<Order> _orderRepository;


        public OrderController(IRepository<Order> orderRepository)
        {
            _orderRepository = orderRepository;
        }


        [HttpGet("get")]
        public IEnumerable<Order> Get()
        {
            return _orderRepository.GetAll();
        }

        [HttpPost("add")]
        public ObjectResult Add(OrderDto ordertDto)
        {
            _orderRepository.Add(new Order(ordertDto.OrderNumber, ordertDto.OrderDate, ordertDto.CustomerId));
            _orderRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public ObjectResult Update(int id, OrderDto OrderDto)
        {
            throw new NotImplementedException();
        }



        [HttpPut("delete")]
        public ObjectResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
