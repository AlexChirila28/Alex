﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CategoryController : ControllerBase
    {

        private readonly IRepository<Category> _categoryRepository;


        public CategoryController(IRepository<Category> categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }


        [HttpGet("get")]
        public IEnumerable<Category> Get()
        {
            return _categoryRepository.GetAll();
        }

        [HttpPost("add")]
        public ObjectResult Add(CategoryDto categoryDto)
        {
            _categoryRepository.Add(new Category(categoryDto.Name));
            _categoryRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public ObjectResult Update(int id, CategoryDto categoryDto)
        {
            throw new NotImplementedException();
        }



        [HttpPut("delete")]
        public ObjectResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
