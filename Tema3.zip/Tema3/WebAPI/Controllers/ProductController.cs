﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {

        private readonly IRepository<Product> _productRepository;


        public ProductController(IRepository<Product> productRepository)
        {
            _productRepository = productRepository;
        }


        [HttpGet("get")]
        public IEnumerable<Product> Get()
        {
            return _productRepository.GetAll();
        }

        [HttpPost("add")]
        public ObjectResult Add(ProductDto productDto)
        {
            _productRepository.Add(new Product(productDto.Name, productDto.Description, productDto.Price, productDto.Stock));
            _productRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public ObjectResult Update(int id, ProductDto productDto)
        {
            throw new NotImplementedException();
        }



        [HttpPut("delete")]
        public ObjectResult Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
