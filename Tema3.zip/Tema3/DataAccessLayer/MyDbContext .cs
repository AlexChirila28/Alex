﻿using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace DataAccessLayer
{
    //Install: Microsoft.EntityFrameworkCore.SqlServer, Microsoft.EntityFrameworkCore.Design
    // dotnet ef migrations add Initial
    // dotnet ef database update
    public class MyDbContext : DbContext
    {
        private readonly string _windowsConnectionString = @"Server=.\SQLExpress;Database=TemaDatabase1;Trusted_Connection=True;TrustServerCertificate=true";
        //private readonly string _windowsConnectionString = @"Server=localhost\SQLEXPRESS;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=True;";

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Passport> Passports { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; } 


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_windowsConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            //one-to-many
            builder.Entity<Order>()
                .HasOne(f => f.Customer)
                .WithMany(c => c.Orders)
                .HasForeignKey(f => f.CustomerId);

            //one-to-one
            builder.Entity<Customer>()
                .HasOne(c => c.Passport)
                .WithOne(p => p.Customer)
                .HasForeignKey<Passport>(p => p.CustomerId);

            //many-to-many
            builder.Entity<Product>()
                .HasMany(p=>p.Categories)
                .WithMany(c => c.Products)
                .UsingEntity(j => j.ToTable("ProductToCategories"));

            Seed(builder);
        }

        protected void Seed(ModelBuilder modelBuilder)
        {

            var fixedDate = new DateTime(2023, 1, 9);
            var expiryDate1 = new DateTime(2028, 7, 11); 
            var expiryDate2 = new DateTime(2026, 5, 10); 

            modelBuilder.Entity<Customer>().HasData(
                new Customer("John Silver", "jsilver@gmail.com", "password123") { Id = 1 },
                new Customer("Alex Black", "ablack@gmail.com", "qwerty") { Id = 2 }
            );

            modelBuilder.Entity<Order>().HasData(
                new Order("123456", fixedDate, 1) { Id = 1 },
                new Order("654321", fixedDate, 2) { Id = 2 }
            );

            modelBuilder.Entity<Passport>().HasData(
                new Passport
                {
                    Id = 1,
                    PassportNumber = "A12345678",
                    Nationality = "USA",
                    ExpiryDate = expiryDate1,
                    CustomerId = 1
                },
                new Passport
                {
                    Id = 2,
                    PassportNumber = "B98765432",
                    Nationality = "Canada",
                    ExpiryDate = expiryDate2,
                    CustomerId = 2
                }
            );


            modelBuilder.Entity<Category>().HasData(
                new Category("Electronics") { Id = 1 },
                new Category("Smartphones") { Id = 2 }
            );

            
            modelBuilder.Entity<Product>().HasData(
                new Product("iPhone 13", "Latest Apple smartphone", 999, 50) { Id = 1 },
                new Product("Samsung Galaxy S21", "Latest Samsung smartphone", 899, 39) { Id = 2 }
            );

            
            modelBuilder.Entity<Product>()
                .HasMany(p => p.Categories)
                .WithMany(c => c.Products)
                .UsingEntity<Dictionary<string, object>>(
                    "ProductToCategories",
                    j => j.HasOne<Category>().WithMany().HasForeignKey("CategoriesId"),
                    j => j.HasOne<Product>().WithMany().HasForeignKey("ProductsId"),
                    j =>
                    {
                        j.HasKey("ProductsId", "CategoriesId");
                        j.HasData(
                            new { ProductsId = 1, CategoriesId = 1 }, 
                            new { ProductsId = 1, CategoriesId = 2 }, 
                            new { ProductsId = 2, CategoriesId = 1 }, 
                            new { ProductsId = 2, CategoriesId = 2 }  
                        );
                    });
        }
    }

    
}

