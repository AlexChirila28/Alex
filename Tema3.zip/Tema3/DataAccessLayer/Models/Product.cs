﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Models
{
    public class Product
    {
        public Product(string name, string description, double price, int stock)
        {
            Name = name;
            Description = description;
            Price = price;
            Stock = stock;
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }

        public ICollection<Category> Categories { get; set; }
    }
}
