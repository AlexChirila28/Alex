﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Models
{
    public class Passport
    {
        public int Id { get; set; }
        public string PassportNumber { get; set; }
        public string Nationality { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }
    }
}
